<?php
/*
Plugin Name: CLI Button Tracker Report
Description: Adiciona um comando WP-CLI para imprimir um relatório do histórico de cliques do botão.
Version: 1.0
Author: Leonardo Lima
*/

if ( defined( 'WP_CLI' ) && WP_CLI ) {

    // A função de callback para o comando WP-CLI
    $bt_cli_report_command = function() {
        global $wpdb;
        $nome_tabela = $wpdb->prefix . 'button_tracker';
        
        // Busca os últimos 10 registros de cliques no banco de dados
        $resultados = $wpdb->get_results( "SELECT * FROM $nome_tabela ORDER BY click_time DESC LIMIT 10" );
        
        if ( empty( $resultados ) ) {
            WP_CLI::line( "Nenhum registro de clique encontrado." );
            return;
        }
        
        // Imprime o cabeçalho do relatório
        WP_CLI::line( "Relatório de Cliques do Botão:" );
        WP_CLI::line( str_pad( "Hora do Clique", 25 ) . "ID" );
        WP_CLI::line( str_repeat( '=', 30 ) );
        
        // Percorre os registros e os imprime
        foreach ( $resultados as $registro ) {
            WP_CLI::line( str_pad( $registro->click_time, 25 ) . $registro->id );
        }
    };

    // Comando WP-CLI para listar os registros de cliques do botão
    WP_CLI::add_command( 'button-tracker report', $bt_cli_report_command );
}

?>
