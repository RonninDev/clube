function bt_register_click() {
    jQuery.post(bt_ajax_obj.ajaxurl, {
        action: 'bt_register_click'
    }, function(response) {
        alert('Clique registrado!');
    });
}
