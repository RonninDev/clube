<?php
/*
Plugin Name: Button Tracker
Description: Adiciona um shortcode que mostra um botão para rastreamento de cliques.
Version: 1.0
Author: Leonardo Lima
*/

// Inclui o manipulador do banco de dados
require_once plugin_dir_path( __FILE__ ) . 'db-handler.php';

// Ativação do plugin: cria a tabela no banco de dados
function bt_activate_plugin() {
    bt_create_table();
}
register_activation_hook( __FILE__, 'bt_activate_plugin' );

// Shortcode que exibe o botão e lida com o AJAX
function bt_add_button_shortcode() {
    // Adiciona o código JavaScript para o AJAX
    wp_enqueue_script('bt-ajax-script', plugins_url('/js/bt-ajax.js', __FILE__), array('jquery'));
    wp_localize_script('bt-ajax-script', 'bt_ajax_obj', array( 'ajaxurl' => admin_url('admin-ajax.php') ));

    // O botão que será mostrado no site
    return '<button id="bt-track-button" onclick="bt_register_click()">Clique Aqui</button>';
}
add_shortcode('bt_button', 'bt_add_button_shortcode');

// Manipulação do AJAX para registrar o clique
function bt_handle_click() {
    bt_insert_click_record();
    wp_die(); // termina a chamada do AJAX corretamente
}
add_action('wp_ajax_bt_register_click', 'bt_handle_click');
add_action('wp_ajax_nopriv_bt_register_click', 'bt_handle_click');
?>
